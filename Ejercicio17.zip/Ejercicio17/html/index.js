// index.js
async function login() {
  const usuario = document.getElementById("usuario").value;
  const password = document.getElementById("password").value;
  const erroresDiv = document.getElementById("errores");

  try {
      const response = await fetch(`/login/${usuario}/${password}`);
      
      if (response.ok) {
          const token = await response.text(); // Obtener el token en texto plano
          erroresDiv.textContent = "Login exitoso!";
          
          // Guarda el token en el almacenamiento local o sesión para su uso posterior
          localStorage.setItem("token", token);
      } else {
          erroresDiv.textContent = "Usuario o contraseña incorrectos.";
      }
  } catch (error) {
      erroresDiv.textContent = "Ocurrió un error en la conexión.";
      console.error("Error:", error);
  }
}
