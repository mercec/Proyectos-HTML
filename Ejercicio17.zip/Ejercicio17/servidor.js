const mariadb = require('mariadb');
const express = require('express');
const jwt = require('jsonwebtoken');

const app = express();

// Configuración de la conexión a la base de datos
const pool = mariadb.createPool({
    host: 'localhost',         // Dirección del servidor de base de datos
    user: 'root',              // Usuario de la base de datos (ajusta según tu configuración)
    password: '',              // Contraseña de la base de datos (ajusta según tu configuración)
    database: 'escuela',       // Especifica tu base de datos aquí
    port: 3306,                // Puerto (3306 es el puerto predeterminado para MySQL/MariaDB)
    connectionLimit: 5
});

// Configuración del servidor y JWT
const JWT_SECRET_KEY = "gfg_jwt_secret_key";
const TOKEN_HEADER_KEY = "gfg_token_header_key";

app.use(express.static("html"));
app.set("view engine", "ejs");

// Generar JWT y autenticar con la base de datos
app.get("/login/:user?/:password?", async (req, res) => {
    const userText = req.params.user;
    const pwdText = req.params.password;

    let conn;
    try {
        conn = await pool.getConnection();
        const rows = await conn.query("SELECT * FROM alumnos WHERE alumnos = ? AND contrasenia = ?", [userText, pwdText]);

        if (rows.length > 0) {
            // Usuario encontrado, generar el token JWT
            const token = jwt.sign({ time: Date(), userId: rows[0].id }, JWT_SECRET_KEY);
            res.send(token);
        } else {
            // Usuario o contraseña incorrectos
            res.status(401).send("Usuario inválido");
        }
    } catch (err) {
        console.error("Error en la conexión o consulta:", err);
        res.status(500).send("Error en el servidor");
    } finally {
        if (conn) await conn.end();
    }
});

// Middleware para verificar el token
const authenticateToken = (req, res, next) => {
    try {
        const token = req.header(TOKEN_HEADER_KEY);
        const verified = jwt.verify(token, JWT_SECRET_KEY);
        if (verified) {
            next();
        } else {
            return res.status(401).send("Token inválido");
        }
    } catch (error) {
        return res.status(401).send("Error de autenticación");
    }
};

// Ruta protegida
app.get('/inicio/:user?', authenticateToken, (req, res) => {
    res.render("inicio", { usuario: req.params.user });
});

// Inicializar servidor
app.listen(3010, () => {
  console.log("Server is up and running on port 3001...");
});

